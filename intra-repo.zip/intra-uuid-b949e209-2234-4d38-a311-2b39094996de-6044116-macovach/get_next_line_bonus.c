/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line_bonus.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: macovach <macovach@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/15 20:48:06 by macovach          #+#    #+#             */
/*   Updated: 2024/12/15 20:48:07 by macovach         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line_bonus.h"

static char *take_after_new_line(char *temp)
{
	int i;
	int j;
	char *dest;

	i = 0;
	while (temp[i] && temp[i] != '\n') i++;
	if (!temp[i])
	{
		free(temp);
		return (NULL);
	}
	dest = malloc(sizeof(char) * (ft_strlen(temp) - i + 1));
	if (!dest)
		return (free(temp), NULL);
	j = 0;
	while (temp[i]) dest[j++] = temp[++i];
	dest[j] = '\0';
	free(temp);
	return (dest);
}

static char *take_until_new_line(char *str)
{
	int i;
	char *dest;

	i = 0;
	if (!str[i])
		return (NULL);
	while (str && str[i] && str[i] != '\n') i++;
	if (str[i] == '\n')
		i++;
	dest = malloc(sizeof(char) * (i + 1));
	if (!dest)
		return (NULL);
	i = 0;
	while (str && str[i] && str[i] != '\n')
	{
		dest[i] = str[i];
		i++;
	}
	if (str[i] == '\n')
		dest[i++] = '\n';
	dest[i] = '\0';
	return (dest);
}

static char *read_until_new_line(int fd, char **str)
{
	char *buff;
	int bytes_read;

	if (!*str)
	{
		*str = malloc(1 * sizeof(char));
		*str[0] = '\0';
	}
	if (!*str)
		return (NULL);
	buff = malloc((BUFFER_SIZE + 1) * sizeof(char));
	if (!buff)
		return (free(*str), NULL);
	bytes_read = 1;
	while (!ft_strchr(*str, '\n') && bytes_read != 0)
	{
		bytes_read = read(fd, buff, BUFFER_SIZE);
		if (bytes_read == -1)
		{
			free(buff);
			free(*str);
			*str = NULL;  // Reset the static buffer to NULL
			return (NULL);
		}
		buff[bytes_read] = '\0';
		*str = ft_strjoin(*str, buff);
		if (!*str)
			return (free(buff), NULL);
	}
	return (free(buff), *str);
}

char *get_next_line(int fd)
{
	static char *str[1024];
	char *line;

	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	str[fd] = read_until_new_line(fd, &str[fd]);
	if (!str[fd])
		return (0);
	line = take_until_new_line(str[fd]);
	if (!line)
	{
		free(line);
		free(str[fd]);
		str[fd] = NULL;
		return (NULL);
	}
	str[fd] = take_after_new_line(str[fd]);
	return (line);
}
